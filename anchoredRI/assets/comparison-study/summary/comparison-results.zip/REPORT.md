# Repeated comparison results

All 45 scenarios and 20 replicates completed: 900 matched datasets. Errors are percentages of true healthy interval width. refineR uses fullDataEst, without bootstrap aggregation.

| Method | Mean error | Failed / 900 | Error >10% or failed / 900 |
|---|---:|---:|---:|
| refineR | 95.62 | 0 | 658 |
| gmm_largest | 131.58 | 0 | 590 |
| gmm_lowest | 29.17 | 0 | 427 |
| pooled40 | 14.09 | 0 | 304 |
| anchored40 | 14.06 | 0 | 289 |
| direct40 | 13.60 | 0 | 600 |
| direct120 | 8.69 | 0 | 285 |
| direct400 | 5.40 | 0 | 105 |

Mean errors average scenario means; failure counts are reported separately. The 10% threshold is exploratory, not a clinical acceptance threshold.

| Paired comparison (A minus B) | Mean difference | Scenarios favoring A / 45 | Finite paired wins for A |
|---|---:|---:|---:|
| anchored40 minus refineR | -81.56 | 36 | 693 / 900 |
| pooled40 minus gmm_largest | -117.49 | 40 | 740 / 900 |
| anchored40 minus pooled40 | -0.03 | 34 | 410 / 900 |
| pooled40 minus gmm_lowest | -15.09 | 35 | 651 / 900 |
| anchored40 minus direct40 | 0.46 | 34 | 617 / 900 |
| anchored40 minus direct120 | 5.37 | 28 | 535 / 900 |
| anchored40 minus direct400 | 8.66 | 23 | 446 / 900 |

Negative differences favor A. Shared anchors across scenarios prevent treating all 900 paired differences as independent for a pooled confidence interval. Scenario-specific Monte Carlo SEs are in paired-comparisons.csv.

These are follow-up simulations within the model family. They do not establish clinical validity, novelty, or performance under misspecification. The lowest-component rule exploits the direction of disease shifts in this design.
