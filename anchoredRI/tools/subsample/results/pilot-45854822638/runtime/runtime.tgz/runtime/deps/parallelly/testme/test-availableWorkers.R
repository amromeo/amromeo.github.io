library(parallelly)

availableCoresPJM <- parallelly:::availableCoresPJM

message("*** availableWorkers() ...")

## The default
w <- availableWorkers()
print(w)
stopifnot(is.character(w), length(w) >= 1)

## Minimium of all known settings (default)
print(availableWorkers(which = "min"))

## Maximum of all known settings (should never be used)
print(availableWorkers(which = "max"))

## All known settings
print(availableWorkers(na.rm = FALSE, which = "all"))

## System settings
w <- availableWorkers(methods = "system")
print(w)
stopifnot(is.character(w), length(w) >= 1)

## Contrain by number of available connections
opts <- options(mc.cores = availableConnections())
w <- availableWorkers(constraints = "connections", method = "mc.cores")
print(w)
stopifnot(is.character(w), length(w) >= 1)
w0 <- w
w <- availableWorkers(constraints = "connections-1", method = "mc.cores")
print(w)
stopifnot(is.character(w), length(w) >= 1, length(w) == length(w0) - 1L)
w <- availableWorkers(constraints = "connections-2", method = "mc.cores")
print(w)
stopifnot(is.character(w), length(w) >= 1, length(w) == length(w0) - 2L)
options(opts)

## Predefined ones for known cluster schedulers
print(availableWorkers(methods = "PBS"))
print(availableWorkers(methods = "SGE"))
print(availableWorkers(methods = "Slurm"))
print(availableWorkers(methods = "LSF"))
print(availableWorkers(methods = "PJM"))
print(availableWorkers(methods = "HTCondor"))


message("*** HPC related ...")

message("*** HTCondor ...")
machine_ad_file <- tempfile(fileext = ".ad")
writeLines(c(
  "MyType = \"Machine\"",
  "Cpus = 3"
), con = machine_ad_file)

Sys.setenv("_CONDOR_MACHINE_AD" = machine_ad_file)
env <- environment(parallelly:::availableCoresHTCondor)
env$n <- NULL
workers <- availableWorkers(methods = "HTCondor")
print(workers)
stopifnot(length(workers) == 3L, all(workers == "localhost"))

file.remove(machine_ad_file)
Sys.unsetenv("_CONDOR_MACHINE_AD")
env$n <- NULL
message("*** HTCondor ... done")

message("*** HTCondor scenarios observed on real clusters ...")

file <- system.file(package = "parallelly", "test-data", "htcondor", "scenarios.csv", mustWork = FALSE)
if (nzchar(file) && file.exists(file)) {
  scenarios <- read.csv(file, colClasses = "character", na.strings = "", check.names = FALSE)
  
  machine_ad_cols <- grep("^_CONDOR_MACHINE_AD-", colnames(scenarios), value = TRUE)
  job_ad_cols <- grep("^_CONDOR_JOB_AD-", colnames(scenarios), value = TRUE)
  meta_cols <- c("cluster", "context", "condor_submit", "expected_cores", "expected_workers", machine_ad_cols, job_ad_cols)
  env_vars <- setdiff(colnames(scenarios), meta_cols)
  
  env <- environment(parallelly:::availableCoresHTCondor)
  
  for (kk in seq_len(nrow(scenarios))) {
    scenario <- scenarios[kk, ]
    message(sprintf("- Scenario #%d of %d: %s %s (%s)", kk, nrow(scenarios), scenario$context, scenario$condor_submit, scenario$cluster))
    
    m_attrs <- as.list(scenario[machine_ad_cols])
    m_attrs <- m_attrs[!is.na(m_attrs)]
    if (length(m_attrs) > 0L) {
      m_lines <- sprintf("%s = %s", sub("^_CONDOR_MACHINE_AD-", "", names(m_attrs)), unlist(m_attrs))
      machine_ad_file <- tempfile(fileext = ".ad")
      writeLines(m_lines, con = machine_ad_file)
      Sys.setenv("_CONDOR_MACHINE_AD" = machine_ad_file)
    } else {
      machine_ad_file <- NULL
      Sys.unsetenv("_CONDOR_MACHINE_AD")
    }
    
    j_attrs <- as.list(scenario[job_ad_cols])
    j_attrs <- j_attrs[!is.na(j_attrs)]
    if (length(j_attrs) > 0L) {
      j_lines <- sprintf("%s = %s", sub("^_CONDOR_JOB_AD-", "", names(j_attrs)), unlist(j_attrs))
      job_ad_file <- tempfile(fileext = ".ad")
      writeLines(j_lines, con = job_ad_file)
      Sys.setenv("_CONDOR_JOB_AD" = job_ad_file)
    } else {
      job_ad_file <- NULL
      Sys.unsetenv("_CONDOR_JOB_AD")
    }
    
    envs <- as.list(scenario[env_vars])
    envs <- envs[!is.na(envs)]
    Sys.unsetenv(env_vars)
    if (length(envs) > 0L) {
      do.call(Sys.setenv, envs)
    }
    
    env$n <- NULL
    
    exp_w <- scenario$expected_workers
    if (is.na(exp_w) || !nzchar(exp_w)) {
      truth <- rep("localhost", times = as.integer(scenario$expected_cores))
    } else {
      truth <- strsplit(exp_w, split = ",", fixed = TRUE)[[1]]
    }
    
    w <- availableWorkers(methods = "HTCondor")
    stopifnot(
      length(w) == length(truth),
      identical(w, truth)
    )
    
    if (!is.null(machine_ad_file)) file.remove(machine_ad_file)
    if (!is.null(job_ad_file)) file.remove(job_ad_file)
    Sys.unsetenv(c("_CONDOR_MACHINE_AD", "_CONDOR_JOB_AD", env_vars))
    env$n <- NULL
  }
}

message("*** HTCondor scenarios observed on real clusters ... done")

sge_expand_node_count_pairs <- parallelly:::sge_expand_node_count_pairs
read_pbs_nodefile <- parallelly:::read_pbs_nodefile
read_pjm_nodefile <- parallelly:::read_pjm_nodefile
read_pe_hostfile <- parallelly:::read_pe_hostfile

workers0 <- c("n1", "n2", "n3", "n1", "n6", "n3", "n3", "n5")
data0 <- as.data.frame(table(workers0), stringsAsFactors = FALSE)
colnames(data0) <- c("node", "count")
data0 <- data0[order(data0$node, data0$count), ]


message("*** LSF ...")

Sys.setenv(LSB_HOSTS = paste(workers0, collapse = " "))
workers <- availableWorkers(methods = "LSF")
print(workers)
stopifnot(length(workers) == length(workers0))

message("*** LSF ... done")



message("*** read_pbs_nodefile() ...")

workers <- workers0
pathname <- tempfile()
writeLines(workers, con = pathname)

data <- read_pbs_nodefile(pathname)
str(data)
stopifnot(
  c("node") %in% colnames(data),
  is.character(data$node),
  !anyNA(data$node),
  nrow(data$node) == length(workers),
  all(sort(data$node) == sort(workers))
)

Sys.setenv(PBS_NODEFILE = pathname)
Sys.setenv(PBS_NP = length(workers),
           PBS_NUM_NODES = length(workers) / 2,
           PBS_NUM_PPN = 2)
workers <- availableWorkers(methods = "PBS")
print(workers)
stopifnot(length(workers) == length(workers0), all(workers == sort(workers0)))

Sys.setenv(PBS_NUM_PPN = 3)
res <- tryCatch({
  workers <- availableWorkers(methods = "PBS")
}, warning = identity)
stopifnot(inherits(res, "warning"))

Sys.setenv(PBS_NP = length(workers) + 1)
res <- tryCatch({
  workers <- availableWorkers(methods = "PBS")
}, warning = identity)
stopifnot(inherits(res, "warning"))

## Unset optional PBS_NP, PBS_NUM_NODES, and PBS_NUM_PPN environment
## variables should not produce warnings
Sys.unsetenv("PBS_NP")
Sys.unsetenv("PBS_NUM_NODES")
Sys.unsetenv("PBS_NUM_PPN")
res <- tryCatch({
  workers <- availableWorkers(methods = "PBS")
}, warning = identity)
stopifnot(!inherits(res, "warning"))

## Exceptions
workersE <- c(workers, "n 3")
pathname <- tempfile()
writeLines(workersE, con = pathname)
res <- tryCatch(read_pbs_nodefile(pathname), error = identity)
print(res)
stopifnot(inherits(res, "error"))

Sys.setenv(PBS_NODEFILE = "<non-existing-file>")
res <- tryCatch({
  workers <- availableWorkers(methods = "PBS")
}, warning = identity)
stopifnot(inherits(res, "warning"))

message("*** read_pbs_nodefile() ... DONE")




message("*** read_pjm_nodefile() ...")

workersT <- unique(workers0)
pathname <- tempfile()
writeLines(workersT, con = pathname)
message(sprintf("Workers in 'PJM_O_NODEINF' file: [n=%d] %s", length(workersT), paste(sQuote(workersT), collapse = ", ")))
data <- read_pjm_nodefile(pathname)
str(data)
stopifnot(
  c("node") %in% colnames(data),
  is.character(data$node),
  !anyNA(data$node),
  nrow(data$node) == length(workersT),
  all(sort(data$node) == sort(workersT)),
  identical(data$node, unique(data$node))
)

Sys.setenv(PJM_O_NODEINF = pathname)

message("- PJM_VNODE_CORE=1")
Sys.setenv(PJM_VNODE_CORE = "1")

## Clear memoization cache
environment(availableCoresPJM)$n <- NULL
workers <- availableWorkers(methods = "PJM")
print(workers)
stopifnot(
  length(workers) == length(workersT),
  all(sort(workers) == sort(workersT))
)

message("- PJM_VNODE=", length(workersT))
message("- PJM_VNODE_CORE=2")
Sys.setenv(PJM_VNODE = length(workersT))
Sys.setenv(PJM_VNODE_CORE = "2")
## Clear memoization cache
environment(availableCoresPJM)$n <- NULL
workers <- availableWorkers(methods = "PJM")
print(workers)
stopifnot(
  length(workers) == 2L * length(workersT),
  all(workers %in% workersT),
  all(workersT %in% workers)
)

message("- PJM_VNODE=1 (incompatible => warning)")
message("- PJM_VNODE_CORE=2")
Sys.setenv(PJM_VNODE = "1")
Sys.setenv(PJM_VNODE_CORE = "2")
## Clear memoization cache
environment(availableCoresPJM)$n <- NULL
workers <- availableWorkers(methods = "PJM")
print(workers)
stopifnot(
  length(workers) == 2L * length(workersT),
  all(workers %in% workersT),
  all(workersT %in% workers)
)


message("- PJM_O_NODEINF = <non-existing-file>")
Sys.setenv(PJM_O_NODEINF = "<non-existing-file>")
res <- tryCatch({
  workers <- availableWorkers(methods = "PJM")
}, warning = identity)
stopifnot(inherits(res, "warning"))

message("*** read_pjm_nodefile() ... DONE")



message("*** read_pe_hostfile() ...")

workers <- workers0
pathname <- tempfile()
write.table(data0, file = pathname, quote = FALSE, row.names = FALSE, col.names = FALSE)
lines <- readLines(pathname)
print(lines)
data <- read_pe_hostfile(pathname, expand = FALSE)
print(data)
stopifnot(
  is.character(data$node),
  !anyNA(data$node),
  is.integer(data$count),
  !anyNA(data$count),
  all(is.finite(data$count)),
  all(data$count > 0),
  nrow(data) == nrow(data0),
  all.equal(data[, c("node", "count")], data0[, c("node", "count")])
)

workers <- sge_expand_node_count_pairs(data)
stopifnot(length(workers) == length(workers0), all(workers == sort(workers0)))

Sys.setenv(PE_HOSTFILE = pathname)
Sys.setenv(NSLOTS = length(workers0))  ## Use to validate results
workers <- availableWorkers(methods = "SGE")
print(workers)
stopifnot(length(workers) == length(workers0), all(workers == sort(workers0)))

## Test validation
Sys.setenv(NSLOTS = length(workers0) + 1L)
workers <- tryCatch(availableWorkers(methods = "SGE"), warning = identity)
print(workers)
stopifnot(inherits(workers, "warning"))

Sys.setenv(PE_HOSTFILE = "<non-existing-file>")
res <- tryCatch({
  workers <- availableWorkers(methods = "SGE")
}, warning = identity)
stopifnot(inherits(res, "warning"))

message("*** read_pe_hostfile() ... DONE")


message("*** Slurm w/ SLURM_JOB_NODELIST ...")

slurm_expand_nodelist <- parallelly:::slurm_expand_nodelist

specs <- list(
  "n1" = c("n1"),
  "  n1" = c("n1"),
  "n1,,  n3" = c("n1", "n3"),
  "n1,  n3" = c("n1", "n3"),
  "n3  n1" = c("n3", "n1"),
  "n[1-13]" = sprintf("n%d", c(1:13)),
  ## scontrol show hostname treats "n[1,3-4,  11-13]" == "n[1,3-4,0011-13]"
  "n[1,3-4,  11-13]" = c("n1", "n3", "n4", "n0011", "n0012", "n0013"),
  "a1,b[   02-04,6-7]" = c("a1", "b00002", "b00003", "b00004", "b6", "b7"),
  "b04-[09-11]" = c("b04-09", "b04-10", "b04-11"),
  "b04-[009-011]" = c("b04-009", "b04-010", "b04-011"),
  "b04-[0009-11]" = c("b04-0009", "b04-0010", "b04-0011"),
  "b04-[9-011]" = c("b04-9", "b04-10", "b04-11")
)

## All combined
all <- list(unlist(specs, use.names = FALSE))
names(all) <- paste(names(specs), collapse = ",")
specs <- c(specs, all)

## Again, all combined but in reverse order 
all <- list(unlist(rev(specs), use.names = FALSE))
names(all) <- paste(rev(names(specs)), collapse = ",")
specs <- c(specs, all)

for (kk in seq_along(specs)) {
  message(sprintf("- Specification #%d of %d", kk, length(specs)))
  nodelist <- names(specs)[kk]
  truth <- specs[[kk]]
  cat(sprintf("nodelist: %s\n", sQuote(nodelist)))
  expanded <- slurm_expand_nodelist(nodelist, manual = TRUE)
  cat(sprintf("expanded: c(%s)\n", paste(sQuote(expanded), collapse = ", ")))
  cat(sprintf("truth: c(%s)\n", paste(sQuote(truth), collapse = ", ")))
  stopifnot(
    is.character(expanded),
    !anyNA(expanded),
    length(expanded) == length(truth),
    identical(expanded, truth)
  )

  Sys.unsetenv(c("SLURM_JOB_NODELIST", "SLURM_NODELIST",
                 "SLURM_JOB_CPUS_PER_NODE", "SLURM_TASKS_PER_NODE"))

  ## Test without SLURM_JOB_CPUS_PER_NODE/SLURM_TASKS_PER_NODE
  Sys.setenv(SLURM_JOB_NODELIST = nodelist)
  for (name in c("SLURM_JOB_NODELIST", "SLURM_JOB_CPUS_PER_NODE")) {
    cat(sprintf("%s = %s\n", name, sQuote(Sys.getenv(name))))
  }
  workers <- availableWorkers(methods = "Slurm")
  cat(sprintf("workers: c(%s)\n", paste(sQuote(workers), collapse = ", ")))
  stopifnot(identical(workers, truth))


  ## Test with SLURM_JOB_CPUS_PER_NODE/SLURM_TASKS_PER_NODE
  nhosts <- length(expanded)
  ncores_per_host <- sample(1:10, size = nhosts, replace = TRUE)

  ## Handle the case when 'nodelist' result in a non-ordered 'expanded'
  expanded2 <- as.list(expanded)
  for (kk in seq_along(expanded2)) {
    expanded2[[kk]] <- rep(expanded2[[kk]], times = ncores_per_host[kk])
  }
  expanded2 <- unlist(expanded2, use.names = FALSE)

  Sys.setenv(SLURM_JOB_NODELIST = nodelist)
  Sys.setenv(SLURM_JOB_CPUS_PER_NODE = paste(ncores_per_host, collapse = ","))

  for (name in c("SLURM_JOB_NODELIST", "SLURM_JOB_CPUS_PER_NODE")) {
    cat(sprintf("%s = %s\n", name, sQuote(Sys.getenv(name))))
  }
  workers <- availableWorkers(methods = "Slurm")
  cat(sprintf("workers: c(%s)\n", paste(sQuote(workers), collapse = ", ")))
  stopifnot(identical(unique(workers), unique(truth)))
  counts <- table(workers)
  counts <- counts[unique(workers)]
  print(counts)
  counts2 <- table(expanded2)
  counts2 <- counts2[unique(expanded2)]
  print(counts2)
  stopifnot(
    sum(counts) == sum(ncores_per_host),
    sum(counts) == sum(counts2),
    all(counts == counts2)
  )
  
  Sys.unsetenv(c("SLURM_JOB_NODELIST", "SLURM_JOB_CPUS_PER_NODE"))
}

message("*** Slurm w/ SLURM_JOB_NODELIST ... DONE")


message("*** Slurm w/ SLURM_TASKS_PER_NODE ...")

slurm_expand_nodecounts <- parallelly:::slurm_expand_nodecounts

specs <- list(
  "1" = c(1L),
  "1,3" = c(1L,3L),
  "1, 3" = c(1L,3L),
  "2(x3)" = rep(2L, times = 3L),
  "2(x3),3,4(x1)" = c(rep(2L, times = 3L), 3L, 4L)
)

for (kk in seq_along(specs)) {
  message(sprintf("- Specification #%d of %d", kk, length(specs)))
  nodecounts <- names(specs)[kk]
  truth <- specs[[kk]]
  cat(sprintf("nodecounts: %s\n", sQuote(nodecounts)))
  expanded <- slurm_expand_nodecounts(nodecounts)
  cat(sprintf("expanded: c(%s)\n", paste(sQuote(expanded), collapse = ", ")))
  cat(sprintf("truth: c(%s)\n", paste(sQuote(truth), collapse = ", ")))
  stopifnot(
    is.integer(expanded),
    !anyNA(expanded),
    length(expanded) == length(truth),
    identical(expanded, truth)
  )
}

message("*** Slurm w/ SLURM_TASKS_PER_NODE ... DONE")

message("*** Slurm odds'n'ends ...")
# All CPUs allotted on a node are available, regardless of SLURM_CPUS_PER_TASK
Sys.setenv(
  SLURM_JOB_NODELIST = "n1",
  SLURM_JOB_CPUS_PER_NODE = "10(x1)",
  SLURM_CPUS_PER_TASK = "9"
)
w <- parallelly:::availableWorkersSlurm()
str(w)
stopifnot(length(w) == 10L, all(w == "n1"))
Sys.unsetenv(c("SLURM_JOB_NODELIST", "SLURM_JOB_CPUS_PER_NODE", "SLURM_CPUS_PER_TASK"))
message("*** Slurm odds'n'ends ... DONE")


message("*** Slurm scenarios observed on real clusters ...")

## Slurm environment variables recorded on real Slurm clusters, for
## the batch script (context 'batch') and for
## tasks launched by 'srun' (context 'srun'). Empty cells correspond to
## environment variables that are not set
file <- system.file(package = "parallelly", "test-data", "slurm", "scenarios.csv", mustWork = TRUE)
scenarios <- read.csv(file, colClasses = "character", na.strings = "")
slurm_vars <- grep("^SLURM", colnames(scenarios), value = TRUE)

for (kk in seq_len(nrow(scenarios))) {
  scenario <- scenarios[kk, ]
  message(sprintf("- Scenario #%d of %d: %s %s (%s)", kk, nrow(scenarios), scenario$context, scenario$sbatch, scenario$cluster))
  envs <- unlist(scenario[slurm_vars])
  envs <- envs[!is.na(envs)]
  Sys.unsetenv(slurm_vars)
  do.call(Sys.setenv, as.list(envs))
  print(envs)

  ## Expected workers, e.g. "n1*4,n2*2"
  truth <- strsplit(scenario$expected_workers, split = ",", fixed = TRUE)[[1]]
  truth <- structure(as.integer(sub(".*[*]", "", truth)), names = sub("[*].*", "", truth))
  
  w <- availableWorkers(methods = "Slurm")
  counts <- table(w)[names(truth)]
  print(counts)
  stopifnot(
    length(w) == sum(truth),
    identical(unique(w), names(truth)),
    all(counts == truth)
  )
}

## Cleanup
Sys.unsetenv(slurm_vars)

message("*** Slurm scenarios observed on real clusters ... DONE")


message("*** SGE scenarios observed on real clusters ...")

## Grid Engine environment variables recorded on a real SGE cluster.
## Column 'PE_HOSTFILE_content' holds the lines of the
## PE_HOSTFILE file, separated by semicolons
file <- system.file(package = "parallelly", "test-data", "sge", "scenarios.csv", mustWork = TRUE)
scenarios <- read.csv(file, colClasses = "character", na.strings = "")
scenarios <- subset(scenarios, !is.na(expected_workers))
sge_vars <- c("HOSTNAME", "NSLOTS", "NHOSTS", "PE", "PE_HOSTFILE")
ohostname <- Sys.getenv("HOSTNAME", NA_character_)

for (kk in seq_len(nrow(scenarios))) {
  scenario <- scenarios[kk, ]
  message(sprintf("- Scenario #%d of %d: %s %s (%s)", kk, nrow(scenarios), scenario$context, if (is.na(scenario$qsub)) "(no PE)" else scenario$qsub, scenario$cluster))
  envs <- unlist(scenario[intersect(sge_vars, colnames(scenario))])
  envs <- envs[!is.na(envs)]
  Sys.unsetenv(sge_vars)
  do.call(Sys.setenv, as.list(envs))
  pathname <- tempfile(fileext = ".pe_hostfile")
  writeLines(strsplit(scenario$PE_HOSTFILE_content, split = "; ", fixed = TRUE)[[1]], con = pathname)
  Sys.setenv(PE_HOSTFILE = pathname)
  print(envs)

  ## Expected workers, e.g. "n1*4,n2*2"
  truth <- strsplit(scenario$expected_workers, split = ",", fixed = TRUE)[[1]]
  truth <- structure(as.integer(sub(".*[*]", "", truth)), names = sub("[*].*", "", truth))

  w <- availableWorkers(methods = "SGE")
  counts <- table(w)[names(truth)]
  print(counts)
  stopifnot(
    length(w) == sum(truth),
    identical(unique(w), names(truth)),
    all(counts == truth),
    ## Workers on the same host are next to each other, in the order
    ## of PE_HOSTFILE, which lists the host running the job script first
    identical(w, rep(names(truth), times = truth)),
    sub("[.].*", "", w[1]) == sub("[.].*", "", scenario$HOSTNAME)
  )
  file.remove(pathname)
}

## A host listed more than once, and not next to each other
pathname <- tempfile(fileext = ".pe_hostfile")
writeLines(c(
  "n2 1 short.q@n2 UNDEFINED",
  "n1 2 long.q@n1 UNDEFINED",
  "n2 3 long.q@n2 UNDEFINED"
), con = pathname)
Sys.unsetenv(sge_vars)
Sys.setenv(PE_HOSTFILE = pathname, NSLOTS = "6", HOSTNAME = "n2")
w <- availableWorkers(methods = "SGE")
print(w)
stopifnot(identical(w, c(rep("n2", times = 4L), rep("n1", times = 2L))))
file.remove(pathname)

## PE_HOSTFILE set, but NSLOTS not set
pathname <- tempfile(fileext = ".pe_hostfile")
writeLines("n1 2 long.q@n1 UNDEFINED", con = pathname)
Sys.unsetenv(sge_vars)
Sys.setenv(PE_HOSTFILE = pathname, HOSTNAME = "n1")
w <- availableWorkers(methods = "SGE")
print(w)
stopifnot(identical(w, c("n1", "n1")))
file.remove(pathname)

## Cleanup
Sys.unsetenv(sge_vars)
if (!is.na(ohostname)) Sys.setenv(HOSTNAME = ohostname)

message("*** SGE scenarios observed on real clusters ... DONE")

message("*** HPC related ... DONE")


## Any R options and system environment variable
print(availableWorkers(methods = c("width", "FOO_BAR_ENV"),
                     na.rm = FALSE, which = "all"))

## Exception handling
Sys.setenv("FOO_BAR_ENV" = "0")
res <- tryCatch(availableWorkers(methods = "FOO_BAR_ENV"), error = identity)
stopifnot(inherits(res, "error"))


message("*** availableWorkers(methods.excludes) ...")
# Save original option
oopts <- options(parallelly.availableWorkers.methods.excludes = NULL)

methods0 <- names(availableWorkers(na.rm = FALSE, which = "all"))

# Exclude one method via option
options(parallelly.availableWorkers.methods.excludes = "system")
methods1 <- names(availableWorkers(na.rm = FALSE, which = "all"))
stopifnot(
  !"system" %in% methods1,
  all(setdiff(methods0, "system") %in% methods1)
)

# Exclude multiple methods via option (vector)
options(parallelly.availableWorkers.methods.excludes = c("system", "nproc"))
methods2 <- names(availableWorkers(na.rm = FALSE, which = "all"))
stopifnot(
  !any(c("system", "nproc") %in% methods2),
  all(setdiff(methods0, c("system", "nproc")) %in% methods2)
)

# Exclude multiple methods via option (comma-separated string)
options(parallelly.availableWorkers.methods.excludes = "system, nproc")
methods2b <- names(availableWorkers(na.rm = FALSE, which = "all"))
stopifnot(
  !any(c("system", "nproc") %in% methods2b),
  all(setdiff(methods0, c("system", "nproc")) %in% methods2b)
)

# Exclude via environment variable
options(parallelly.availableWorkers.methods.excludes = NULL)
Sys.setenv(R_PARALLELLY_AVAILABLEWORKERS_METHODS_EXCLUDES = "system,nproc")
parallelly:::update_package_options()
methods3 <- names(availableWorkers(na.rm = FALSE, which = "all"))
stopifnot(
  !any(c("system", "nproc") %in% methods3),
  all(setdiff(methods0, c("system", "nproc")) %in% methods3)
)
Sys.unsetenv("R_PARALLELLY_AVAILABLEWORKERS_METHODS_EXCLUDES")
parallelly:::update_package_options()

# Restore options
options(oopts)
message("*** availableWorkers(methods.excludes) ... done")


message("*** availableWorkers(threadsPerWorker) ...")

## Localhost
options(parallelly.availableCores.system = 12L)
options(parallelly.availableCores.methods = "system")
options(parallelly.availableWorkers.methods = "system")

env <- environment(parallelly:::detectCores)
env$cache <- list(NULL, NULL)

stopifnot(length(availableWorkers()) == 12L)
stopifnot(length(availableWorkers(threadsPerWorker = 2L)) == 6L)
stopifnot(length(availableWorkers(threadsPerWorker = 100L)) == 1L)
options(parallelly.availableCores.system = NULL)
options(parallelly.availableCores.methods = NULL)
options(parallelly.availableWorkers.methods = NULL)

## Multiple hosts
workers <- c("n1", "n1", "n1", "n1", "n2", "n2", "n3")

## Custom workers
options(parallelly.availableWorkers.custom = function() workers)
options(parallelly.availableWorkers.methods = "custom")
stopifnot(identical(availableWorkers(threadsPerWorker = 2L), c("n1", "n1", "n2")))
options(parallelly.availableCores.threadsPerWorker = 2L)
stopifnot(identical(availableWorkers(), c("n1", "n1", "n2")))
options(parallelly.availableCores.threadsPerWorker = NULL)
options(parallelly.availableWorkers.custom = NULL)
options(parallelly.availableWorkers.methods = NULL)

res <- tryCatch(availableWorkers(threadsPerWorker = 0L), error = identity)
stopifnot(inherits(res, "error"))

message("*** availableWorkers(threadsPerWorker) ... DONE")


message("*** availableWorkers() ... DONE")
