library(parallelly)

message("*** availableCores() ...")

## detectCores() may return NA_integer_
n <- parallel::detectCores()
message(sprintf("detectCores() = %d", n))
stopifnot(length(n) == 1, is.numeric(n))

## Default
n <- availableCores()
message(sprintf("availableCores() = %d", n))
stopifnot(length(n) == 1, is.integer(n), n >= 1)
n0 <- n

n <- availableCores(omit = 1L)
stopifnot(length(n) == 1, is.integer(n), n >= 1, n == max(1L, n0 - 1L))

n <- availableCores(max = 1L)
stopifnot(length(n) == 1, is.integer(n), n == 1L)

## Minimium of all known settings (default)
print(availableCores(which = "min"))

## Maximum of all known settings (should never be used)
print(availableCores(which = "max"))

## All known settings
ns <- availableCores(na.rm = FALSE, which = "all")
stopifnot(length(ns) >= 1, is.integer(ns), all(is.na(ns) | ns >= 0L))

## System settings
n <- availableCores(methods = "system")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1)

## Contrain by number of available connections
opts <- options(mc.cores = availableConnections())
n <- availableCores(constraints = "connections", method = "mc.cores")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1)
n0 <- n
n <- availableCores(constraints = "connections-1", method = "mc.cores")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1, n == n0 - 1L)
n <- availableCores(constraints = "connections-2", method = "mc.cores")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1, n == n0 - 2L)
n <- availableCores(method = "connections")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1, n == n0)
n <- availableCores(method = "connections-1")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1, n == n0 - 1L)
n <- availableCores(method = "connections-2")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1, n == n0 - 2L)
options(opts)

## Contrain by support for multicore
n <- availableCores(constraints = "multicore")
print(n)
stopifnot(length(n) == 1, is.integer(n), n >= 1)

## Special case: mc.cores = 0L
opts <- options(mc.cores = 0L)
n <- availableCores(method = "mc.cores")
print(n)
stopifnot(length(n) == 1, is.integer(n), n == 1L)
n <- availableCores(method = "mc.cores+1")
print(n)
stopifnot(length(n) == 1, is.integer(n), n == 1L)
options(opts)

## Predefined ones for known cluster schedulers
print(availableCores(methods = "PBS"))
print(availableCores(methods = "SGE"))
print(availableCores(methods = "Slurm"))
print(availableCores(methods = "LSF"))
print(availableCores(methods = "HTCondor"))

## Any R options and system environment variable
print(availableCores(methods = c("width", "FOO_BAR_ENV"),
                     na.rm = FALSE, which = "all"))

## Exception handling
Sys.setenv("FOO_BAR_ENV" = "0")
res <- try(availableCores(methods = "FOO_BAR_ENV"), silent = TRUE)
stopifnot(inherits(res, "try-error"))


ncores0 <- 42L

message("*** LSF ...")
message(" - LSB_DJOB_NUMPROC")
Sys.setenv(LSB_DJOB_NUMPROC = as.character(ncores0))
env <- environment(parallelly:::availableCoresLSF)
env$n <- NULL
ncores <- availableCores(methods = "LSF")
print(ncores)
stopifnot(ncores == ncores0)
message("*** LSF ... done")

message("*** PJM (Fujitsu Technical Computing Suite) ...")
message(" - PJM_VNODE_CORE")
Sys.setenv(PJM_VNODE_CORE = as.character(ncores0))
env <- environment(parallelly:::availableCoresPJM)
env$n <- NULL
ncores <- availableCores(methods = "PJM")
print(ncores)
stopifnot(ncores == ncores0)
Sys.unsetenv("PJM_VNODE_CORE")

message(" - PJM_PROC_BY_NODE")
Sys.setenv(PJM_PROC_BY_NODE = as.character(ncores0))
env <- environment(parallelly:::availableCoresPJM)
env$n <- NULL
ncores <- availableCores(methods = "PJM")
print(ncores)
stopifnot(ncores == ncores0)
Sys.unsetenv("PJM_PROC_BY_NODE")
message("*** PJM (Fujitsu Technical Computing Suite) ... done")

message("*** HTCondor ...")

env <- environment(parallelly:::availableCoresHTCondor)

## Baseline: not in HTCondor
env$n <- NULL
Sys.unsetenv(c("_CONDOR_MACHINE_AD", "_CONDOR_JOB_AD"))
ncores <- availableCores(methods = "HTCondor", na.rm = FALSE)
stopifnot(is.na(ncores[["HTCondor"]]))

## 1. Machine ClassAd: Cpus
machine_ad_file <- tempfile(fileext = ".ad")
writeLines(c(
  "# Comment line",
  "// Another comment",
  "MyType = \"Machine\"",
  "TargetType = \"Job\"",
  "Name = \"slot1@execute01\"",
  "Cpus = 4",
  "TotalCpus = 16"
), con = machine_ad_file)

Sys.setenv("_CONDOR_MACHINE_AD" = machine_ad_file)
env$n <- NULL
ncores <- availableCores(methods = "HTCondor")
print(ncores)
stopifnot(ncores == 4L)

## 2. Machine ClassAd preferred over Job ClassAd
job_ad_file <- tempfile(fileext = ".ad")
writeLines(c(
  "MyType = \"Job\"",
  "TargetType = \"Machine\"",
  "RequestCpus = 2",
  "CpusProvisioned = 4"
), con = job_ad_file)

Sys.setenv("_CONDOR_JOB_AD" = job_ad_file)
env$n <- NULL
ncores <- availableCores(methods = "HTCondor")
stopifnot(ncores == 4L)

## 3. Fallback to Job ClassAd CpusProvisioned (when machine ad not available)
Sys.unsetenv("_CONDOR_MACHINE_AD")
env$n <- NULL
ncores <- availableCores(methods = "HTCondor")
print(ncores)
stopifnot(ncores == 4L)

## 4. Fallback to Job ClassAd Cpus (when CpusProvisioned not available)
writeLines(c(
  "MyType = \"Job\"",
  "TargetType = \"Machine\"",
  "RequestCpus = 1",
  "Cpus = 6"
), con = job_ad_file)
env$n <- NULL
ncores <- availableCores(methods = "HTCondor")
print(ncores)
stopifnot(ncores == 6L)

## 5. Cross-check mismatch between machine ad and job ad
Sys.setenv("_CONDOR_MACHINE_AD" = machine_ad_file)
writeLines(c(
  "MyType = \"Job\"",
  "CpusProvisioned = 8"
), con = job_ad_file)
Sys.setenv("_CONDOR_JOB_AD" = job_ad_file)
env$n <- NULL
warn_msg <- NULL
ncores <- withCallingHandlers({
  availableCores(methods = "HTCondor")
}, warning = function(w) {
  warn_msg <<- conditionMessage(w)
  invokeRestart("muffleWarning")
})
stopifnot(ncores == 4L, !is.null(warn_msg), grepl("CpusProvisioned", warn_msg))

## 6. Non-existent file warning
Sys.setenv("_CONDOR_MACHINE_AD" = tempfile())
Sys.unsetenv("_CONDOR_JOB_AD")
env$n <- NULL
warn_msg <- NULL
ncores <- withCallingHandlers({
  availableCores(methods = "HTCondor", na.rm = FALSE)
}, warning = function(w) {
  warn_msg <<- conditionMessage(w)
  invokeRestart("muffleWarning")
})
stopifnot(is.na(ncores[["HTCondor"]]), !is.null(warn_msg), grepl("no such file", warn_msg))

## Clean up
file.remove(machine_ad_file)
file.remove(job_ad_file)
Sys.unsetenv(c("_CONDOR_MACHINE_AD", "_CONDOR_JOB_AD"))
env$n <- NULL

message("*** HTCondor ... done")

message("*** HTCondor scenarios observed on real clusters ...")

file <- system.file(package = "parallelly", "test-data", "htcondor", "scenarios.csv", mustWork = FALSE)
if (nzchar(file) && file.exists(file)) {
  scenarios <- read.csv(file, colClasses = "character", na.strings = "", check.names = FALSE)
  
  machine_ad_cols <- grep("^_CONDOR_MACHINE_AD-", colnames(scenarios), value = TRUE)
  job_ad_cols <- grep("^_CONDOR_JOB_AD-", colnames(scenarios), value = TRUE)
  meta_cols <- c("cluster", "context", "condor_submit", "expected_cores", "expected_workers", machine_ad_cols, job_ad_cols)
  env_vars <- setdiff(colnames(scenarios), meta_cols)
  
  env <- environment(parallelly:::availableCoresHTCondor)
  
  for (kk in seq_len(nrow(scenarios))) {
    scenario <- scenarios[kk, ]
    message(sprintf("- Scenario #%d of %d: %s %s (%s)", kk, nrow(scenarios), scenario$context, scenario$condor_submit, scenario$cluster))
    
    ## Write machine ad file if any machine ad columns are non-empty
    m_attrs <- as.list(scenario[machine_ad_cols])
    m_attrs <- m_attrs[!is.na(m_attrs)]
    if (length(m_attrs) > 0L) {
      m_lines <- sprintf("%s = %s", sub("^_CONDOR_MACHINE_AD-", "", names(m_attrs)), unlist(m_attrs))
      machine_ad_file <- tempfile(fileext = ".ad")
      writeLines(m_lines, con = machine_ad_file)
      Sys.setenv("_CONDOR_MACHINE_AD" = machine_ad_file)
    } else {
      machine_ad_file <- NULL
      Sys.unsetenv("_CONDOR_MACHINE_AD")
    }
    
    ## Write job ad file if any job ad columns are non-empty
    j_attrs <- as.list(scenario[job_ad_cols])
    j_attrs <- j_attrs[!is.na(j_attrs)]
    if (length(j_attrs) > 0L) {
      j_lines <- sprintf("%s = %s", sub("^_CONDOR_JOB_AD-", "", names(j_attrs)), unlist(j_attrs))
      job_ad_file <- tempfile(fileext = ".ad")
      writeLines(j_lines, con = job_ad_file)
      Sys.setenv("_CONDOR_JOB_AD" = job_ad_file)
    } else {
      job_ad_file <- NULL
      Sys.unsetenv("_CONDOR_JOB_AD")
    }
    
    ## Set environment variables
    envs <- as.list(scenario[env_vars])
    envs <- envs[!is.na(envs)]
    Sys.unsetenv(env_vars)
    if (length(envs) > 0L) {
      do.call(Sys.setenv, envs)
    }
    
    env$n <- NULL
    truth <- as.integer(scenario$expected_cores)
    
    ncores <- availableCores(methods = "HTCondor")
    message(sprintf("availableCores(methods = \"HTCondor\") = %d (truth = %d)", ncores, truth))
    stopifnot(ncores == truth)
    
    ## Cleanup temp files
    if (!is.null(machine_ad_file)) file.remove(machine_ad_file)
    if (!is.null(job_ad_file)) file.remove(job_ad_file)
    Sys.unsetenv(c("_CONDOR_MACHINE_AD", "_CONDOR_JOB_AD", env_vars))
    env$n <- NULL
  }
}

message("*** HTCondor scenarios observed on real clusters ... done")


message("*** Internal detectCores() ...")

## Option 'parallelly.availableCores.system'

## Reset internal cache
env <- environment(parallelly:::detectCores)
env$cache <- list(NULL, NULL)

options(parallelly.availableCores.system = 2L)
n <- detectCores()
print(n)
stopifnot(is.integer(n), is.finite(n), n >= 1, n == 2L)
options(parallelly.availableCores.system = NULL)

## Reset
env <- environment(parallelly:::detectCores)
env$cache <- list(NULL, NULL)

n <- detectCores()
print(n)
stopifnot(is.integer(n), is.finite(n), n >= 1)

message("*** Internal detectCores() ... DONE")


message("*** Slurm multi-node scenarios ...")

## Reset Slurm cache
env <- environment(parallelly:::availableCoresSlurm)

## Single-node with SLURM_CPUS_ON_NODE
Sys.unsetenv("SLURM_CPUS_PER_TASK")
Sys.setenv(SLURM_JOB_NUM_NODES = "1", SLURM_CPUS_ON_NODE = "8")
env$n <- NULL
ncores <- availableCores(methods = "Slurm")
print(ncores)
stopifnot(ncores == 8L)

## SLURM_NNODES fallback when SLURM_JOB_NUM_NODES is not set
Sys.unsetenv("SLURM_CPUS_PER_TASK")
Sys.unsetenv("SLURM_JOB_NUM_NODES")
Sys.setenv(SLURM_NNODES = "1", SLURM_CPUS_ON_NODE = "16")
env$n <- NULL
ncores <- availableCores(methods = "Slurm")
print(ncores)
stopifnot(ncores == 16L)

## Multi-node with SLURM_TASKS_PER_NODE (simple format), which is
## a fallback when SLURM_CPUS_ON_NODE is not set
Sys.unsetenv(c("SLURM_CPUS_PER_TASK", "SLURM_CPUS_ON_NODE"))
Sys.setenv(SLURM_JOB_NUM_NODES = "2", SLURM_TASKS_PER_NODE = "5,2")
env$n <- NULL
ncores <- availableCores(methods = "Slurm")
print(ncores)
stopifnot(ncores == 5L)  ## Uses first node's count

## Multi-node with SLURM_TASKS_PER_NODE (expanded format)
Sys.unsetenv("SLURM_CPUS_PER_TASK")
Sys.setenv(SLURM_JOB_NUM_NODES = "5", SLURM_TASKS_PER_NODE = "2(x2),1(x3)")
env$n <- NULL
ncores <- availableCores(methods = "Slurm")
print(ncores)
stopifnot(ncores == 2L)  ## Uses first node's count

## Cleanup
Sys.unsetenv(c("SLURM_CPUS_PER_TASK", "SLURM_JOB_NUM_NODES", "SLURM_NNODES",
               "SLURM_CPUS_ON_NODE", "SLURM_TASKS_PER_NODE"))
env$n <- NULL

message("*** Slurm multi-node scenarios ... done")


message("*** Slurm scenarios observed on real clusters ...")

## Slurm environment variables recorded on real Slurm clusters, for
## the batch script (context 'batch'), for
## tasks launched by 'srun' (context 'srun'), and for the interactive
## shell of 'salloc' (context 'salloc'). Empty cells correspond to
## environment variables that are not set
file <- system.file(package = "parallelly", "test-data", "slurm", "scenarios.csv", mustWork = TRUE)
scenarios <- read.csv(file, colClasses = "character", na.strings = "")
slurm_vars <- grep("^SLURM", colnames(scenarios), value = TRUE)

env <- environment(parallelly:::availableCoresSlurm)
for (kk in seq_len(nrow(scenarios))) {
  scenario <- scenarios[kk, ]
  message(sprintf("- Scenario #%d of %d: %s %s (%s)", kk, nrow(scenarios), scenario$context, scenario$sbatch, scenario$cluster))
  envs <- unlist(scenario[slurm_vars])
  envs <- envs[!is.na(envs)]
  Sys.unsetenv(slurm_vars)
  do.call(Sys.setenv, as.list(envs))
  print(envs)
  env$n <- NULL
  truth <- as.integer(scenario$expected_cores)
  ## Any warnings are unexpected
  ncores <- withCallingHandlers({
    availableCores(methods = "Slurm")
  }, warning = function(w) {
    stop("Unexpected warning: ", conditionMessage(w))
  })
  message(sprintf("availableCores(methods = \"Slurm\") = %d (truth = %d)", ncores, truth))
  stopifnot(ncores == truth)
}

## Cleanup
Sys.unsetenv(slurm_vars)
env$n <- NULL

message("*** Slurm scenarios observed on real clusters ... done")


message("*** PBS NCPUS fallback ...")

## Reset PBS cache
env <- environment(parallelly:::availableCoresPBS)

## Test NCPUS fallback when PBS_NUM_PPN is not set
Sys.unsetenv("PBS_NUM_PPN")
Sys.setenv(NCPUS = "16")
env$n <- NULL
ncores <- availableCores(methods = "PBS")
print(ncores)
stopifnot(ncores == 16L)

## Cleanup
Sys.unsetenv("NCPUS")
env$n <- NULL

message("*** PBS NCPUS fallback ... done")


message("*** BiocParallel method ...")

Sys.setenv(BIOCPARALLEL_WORKER_NUMBER = "4")
ncores <- availableCores(methods = "BiocParallel")
print(ncores)
stopifnot(ncores == 4L)
Sys.unsetenv("BIOCPARALLEL_WORKER_NUMBER")

message("*** BiocParallel method ... done")


message("*** Bioconductor build machine ...")

## IS_BIOC_BUILD_MACHINE (modern, >= 3.16)
Sys.setenv(IS_BIOC_BUILD_MACHINE = "TRUE")
ncores <- availableCores(methods = "Bioconductor")
print(ncores)
stopifnot(ncores == 4L)
Sys.unsetenv("IS_BIOC_BUILD_MACHINE")

## BBS_HOME fallback (legacy, <= 3.15)
Sys.setenv(BBS_HOME = "TRUE")
ncores <- availableCores(methods = "Bioconductor")
print(ncores)
stopifnot(ncores == 4L)
Sys.unsetenv("BBS_HOME")

message("*** Bioconductor build machine ... done")


message("*** Custom function method ...")

## Valid custom function
opts <- options(parallelly.availableCores.custom = function() 3L)
ncores <- availableCores(methods = "custom")
print(ncores)
stopifnot(ncores == 3L)
options(opts)

## Custom function returning NA (should be ignored)
opts <- options(parallelly.availableCores.custom = function() NA_integer_)
ncores <- availableCores(methods = c("system", "custom"), which = "all", na.rm = FALSE)
print(ncores)
stopifnot("custom" %in% names(ncores), is.na(ncores["custom"]))
options(opts)

## Custom function calling availableCores() (recursion protection)
opts <- options(parallelly.availableCores.custom = function() {
  availableCores(methods = "system") - 1L
})
ncores <- availableCores(methods = "custom")
print(ncores)
stopifnot(ncores >= 1L)
options(opts)

## Error: custom function returns non-single value
opts <- options(parallelly.availableCores.custom = function() c(1L, 2L))
res <- tryCatch(availableCores(methods = "custom"), error = identity)
stopifnot(inherits(res, "error"))
options(opts)

## Custom option is not a function (should be skipped)
opts <- options(parallelly.availableCores.custom = "not a function")
ncores <- availableCores(methods = c("system", "custom"), which = "all")
print(ncores)
stopifnot(!("custom" %in% names(ncores)))
options(opts)

message("*** Custom function method ... done")


message("*** Fallback method ...")

## Test fallback option
opts <- options(parallelly.availableCores.fallback = 2L)
ncores <- availableCores(methods = "fallback")
print(ncores)
stopifnot(ncores == 2L)
options(opts)

## Fallback is used when only "special" methods are present
opts <- options(parallelly.availableCores.fallback = 2L)
ncores <- availableCores(methods = c("system", "fallback"))
print(ncores)
## Fallback should be used if system agrees or is higher
stopifnot(ncores >= 1L)
options(opts)

message("*** Fallback method ... done")


message("*** parallelly.availableCores.min validation ...")

## Error: non-numeric min
opts <- options(parallelly.availableCores.min = "two")
res <- tryCatch(availableCores(), error = identity)
stopifnot(inherits(res, "error"))
options(opts)

## Error: min < 1
opts <- options(parallelly.availableCores.min = 0L)
res <- tryCatch(availableCores(), error = identity)
stopifnot(inherits(res, "error"))
options(opts)

## Error: min is not finite (Inf)
opts <- options(parallelly.availableCores.min = Inf)
res <- tryCatch(availableCores(), error = identity)
stopifnot(inherits(res, "error"))
options(opts)

## Error: min > detectCores()
opts <- options(parallelly.availableCores.min = parallel::detectCores() + 1L)
res <- tryCatch(availableCores(), error = identity)
stopifnot(inherits(res, "error"))
options(opts)

## Error: min has wrong length
opts <- options(parallelly.availableCores.min = c(1L, 2L))
res <- tryCatch(availableCores(), error = identity)
stopifnot(inherits(res, "error"))
options(opts)

message("*** parallelly.availableCores.min validation ... done")


message("*** Input validation edge cases ...")

## Invalid default (< 1)
res <- tryCatch(availableCores(default = 0L), error = identity)
stopifnot(inherits(res, "error"))

## Invalid default (not finite)
res <- tryCatch(availableCores(default = Inf), error = identity)
stopifnot(inherits(res, "error"))

## Invalid default (too large to represent as an integer)
res <- tryCatch(availableCores(default = 1e10), error = identity)
stopifnot(inherits(res, "error"))

## An unnamed default should not get missing names
n <- availableCores(default = 2L, methods = "non-existing-method")
print(n)
stopifnot(n == 2L, is.null(names(n)))

## A non-integer default should be returned as an integer
n <- availableCores(default = 2, methods = "non-existing-method")
print(n)
stopifnot(is.integer(n), n == 2L)
n <- availableCores(default = c(abc = 2), methods = "non-existing-method")
print(n)
stopifnot(is.integer(n), n == 2L, identical(names(n), "abc"))

## ... also not when the minimum number of cores is enforced
if (parallelly:::detectCores() >= 2L) {
  oopts <- options(parallelly.availableCores.min = 2L)
  n <- availableCores(default = 1L, methods = "non-existing-method")
  print(n)
  stopifnot(n == 2L, is.null(names(n)))
  options(oopts)
}

## Invalid omit (negative)
res <- tryCatch(availableCores(omit = -1L), error = identity)
stopifnot(inherits(res, "error"))

## Invalid omit (not finite)
res <- tryCatch(availableCores(omit = Inf), error = identity)
stopifnot(inherits(res, "error"))

## Invalid omit (too large to represent as an integer)
res <- tryCatch(availableCores(omit = 1e10), error = identity)
stopifnot(inherits(res, "error"))

## Invalid max (< 1)
res <- tryCatch(availableCores(max = 0L), error = identity)
stopifnot(inherits(res, "error"))

## Invalid max (NA)
res <- tryCatch(availableCores(max = NA), error = identity)
stopifnot(inherits(res, "error"))

## Invalid constraints (NA values)
res <- tryCatch(availableCores(constraints = c("multicore", NA)), error = identity)
stopifnot(inherits(res, "error"))

message("*** Input validation edge cases ... done")


message("*** checkNumberOfLocalWorkers() ...")

checkNumberOfLocalWorkers <- parallelly:::checkNumberOfLocalWorkers

## AsIs bypass - should not warn or error
result <- tryCatch({
  checkNumberOfLocalWorkers(I(1000L))
  TRUE
}, warning = function(w) FALSE, error = function(e) FALSE)
stopifnot(result)

## Save current options
opts <- options(parallelly.maxWorkers.localhost = c(1.0, 3.0))

## Test warning at soft limit (workers/ncores > 1.0)
ncores <- availableCores()
if (ncores >= 1L) {
  workers <- ncores + 1L  ## Just above soft limit
  res <- tryCatch({
    checkNumberOfLocalWorkers(workers)
    "none"
  }, warning = function(w) "warning", error = function(e) "error")
  message(sprintf("  workers=%d, ncores=%d -> %s", workers, ncores, res))
  stopifnot(res == "warning")
}

## Test error at hard limit (workers/ncores > 3.0)
if (ncores >= 1L) {
  workers <- ncores * 4L  ## Above hard limit
  res <- tryCatch({
    checkNumberOfLocalWorkers(workers)
    "none"
  }, warning = function(w) "warning", error = function(e) "error")
  message(sprintf("  workers=%d, ncores=%d -> %s", workers, ncores, res))
  stopifnot(res == "error")
}

## Restore options
options(opts)

## Test with empty limits (disabled)
## Note: NULL returns default, so use numeric(0) to disable
opts <- options(parallelly.maxWorkers.localhost = numeric(0))
result <- tryCatch({
  checkNumberOfLocalWorkers(1000L)
  TRUE
}, warning = function(w) FALSE, error = function(e) FALSE)
stopifnot(result)
options(opts)

message("*** checkNumberOfLocalWorkers() ... done")


message("*** detectCoresHint() ...")

detectCoresHint <- parallelly:::detectCoresHint
sysCores <- parallel::detectCores()

## Hint for detectCores() pattern
hint <- detectCoresHint(sysCores)
message(sprintf("  detectCoresHint(%d): %s", sysCores, hint))
stopifnot(!is.null(hint), grepl("detectCores", hint))

## Hint for detectCores() - 1 pattern
hint <- detectCoresHint(sysCores - 1L)
message(sprintf("  detectCoresHint(%d): %s", sysCores - 1L, hint))
stopifnot(!is.null(hint), grepl("detectCores", hint), grepl("- 1", hint))

## Hint for detectCores() - 2 pattern
hint <- detectCoresHint(sysCores - 2L)
message(sprintf("  detectCoresHint(%d): %s", sysCores - 2L, hint))
stopifnot(!is.null(hint), grepl("detectCores", hint), grepl("- 2", hint))

## No hint when delta > 2
hint <- detectCoresHint(1L)
message(sprintf("  detectCoresHint(1): %s", if (is.null(hint)) "NULL" else hint))
if (sysCores > 3L) {
  stopifnot(is.null(hint))
}

message("*** detectCoresHint() ... done")


message("*** logical parameter ...")

## Test logical = TRUE (logical/hyperthreaded cores)
n_logical <- availableCores(methods = "system", logical = TRUE)
print(n_logical)
stopifnot(is.integer(n_logical), n_logical >= 1L)

## Test logical = FALSE (physical cores)
n_physical <- availableCores(methods = "system", logical = FALSE)
print(n_physical)
stopifnot(is.integer(n_physical), n_physical >= 1L)

## Physical cores should be <= logical cores
stopifnot(n_physical <= n_logical)

message("*** logical parameter ... done")


message("*** connections-N delta tests ...")

## Get baseline
n_conn <- freeConnections()
message(sprintf("  freeConnections() = %d", n_conn))

## Test various connection deltas
n0 <- availableCores(methods = "connections")
print(n0)
stopifnot(n0 >= 1L)

n5 <- availableCores(methods = "connections-5")
print(n5)
stopifnot(n5 >= 1L)
if (n0 > 5L) {
  stopifnot(n5 == n0 - 5L)
}

## Large delta should still return at least 1
n_large <- availableCores(methods = "connections-1000")
print(n_large)
stopifnot(n_large >= 1L)

message("*** connections-N delta tests ... done")


message("*** na.rm = FALSE with missing values ...")

## Verify NA values are preserved when na.rm = FALSE
ns <- availableCores(methods = c("system", "nonexistent_method_xyz123"),
                     na.rm = FALSE, which = "all")
print(ns)
stopifnot("nonexistent_method_xyz123" %in% names(ns))
stopifnot(is.na(ns["nonexistent_method_xyz123"]))

message("*** na.rm = FALSE with missing values ... done")


message("*** SGE method ...")

## Reset SGE cache
env <- environment(parallelly:::availableCoresSGE)

Sys.setenv(NSLOTS = "24")
env$n <- NULL
ncores <- availableCores(methods = "SGE")
print(ncores)
stopifnot(ncores == 24L)
Sys.unsetenv("NSLOTS")
env$n <- NULL

message("*** SGE method ... done")


message("*** SGE scenarios observed on real clusters ...")

## Grid Engine environment variables recorded on a real SGE cluster,
## for the job script (context 'job') and for processes
## launched by 'qrsh -inherit' (context 'inherit'). Column
## 'PE_HOSTFILE_content' holds the lines of the PE_HOSTFILE file,
## separated by semicolons. Empty cells correspond to environment
## variables that are not set. Processes launched by 'qrsh -inherit'
## have no PE_HOSTFILE, but SGE_JOB_SPOOL_DIR, which is a folder below
## the job's spool folder, e.g. '<spool>/active_jobs/123.1/1.n1'.
## On the host running the job script, the job's spool folder holds
## the 'pe_hostfile' file, whose lines are in column
## 'spool_pe_hostfile_content'. On the other hosts, there is none
file <- system.file(package = "parallelly", "test-data", "sge", "scenarios.csv", mustWork = TRUE)
scenarios <- read.csv(file, colClasses = "character", na.strings = "")
sge_vars <- c("HOSTNAME", "NSLOTS", "NHOSTS", "PE", "PE_HOSTFILE", "SGE_JOB_SPOOL_DIR")
ohostname <- Sys.getenv("HOSTNAME", NA_character_)

env <- environment(parallelly:::availableCoresSGE)
for (kk in seq_len(nrow(scenarios))) {
  scenario <- scenarios[kk, ]
  message(sprintf("- Scenario #%d of %d: %s %s (%s)", kk, nrow(scenarios), scenario$context, if (is.na(scenario$qsub)) "(no PE)" else scenario$qsub, scenario$cluster))
  envs <- unlist(scenario[intersect(sge_vars, colnames(scenario))])
  envs <- envs[!is.na(envs)]
  Sys.unsetenv(sge_vars)
  do.call(Sys.setenv, as.list(envs))
  if (!is.na(scenario$PE_HOSTFILE_content)) {
    pathname <- tempfile(fileext = ".pe_hostfile")
    writeLines(strsplit(scenario$PE_HOSTFILE_content, split = "; ", fixed = TRUE)[[1]], con = pathname)
    Sys.setenv(PE_HOSTFILE = pathname)
  }
  if (scenario$context == "inherit") {
    spool <- file.path(tempfile(), "active_jobs", "123.1")
    task_spool <- file.path(spool, paste0("1.", scenario$HOSTNAME))
    dir.create(task_spool, recursive = TRUE)
    if (!is.na(scenario$spool_pe_hostfile_content)) {
      writeLines(strsplit(scenario$spool_pe_hostfile_content, split = "; ", fixed = TRUE)[[1]], con = file.path(spool, "pe_hostfile"))
    }
    Sys.setenv(SGE_JOB_SPOOL_DIR = task_spool)
  }
  print(envs)
  env$n <- NULL
  truth <- as.integer(scenario$expected_cores)
  ncores <- availableCores(methods = "SGE")
  message(sprintf("availableCores(methods = \"SGE\") = %d (truth = %d)", ncores, truth))
  stopifnot(ncores == truth)
  if (!is.na(scenario$PE_HOSTFILE_content)) file.remove(pathname)
  if (scenario$context == "inherit") unlink(dirname(dirname(spool)), recursive = TRUE)
}

## Cleanup
Sys.unsetenv(sge_vars)
if (!is.na(ohostname)) Sys.setenv(HOSTNAME = ohostname)
env$n <- NULL

message("*** SGE scenarios observed on real clusters ... done")


message("*** _R_CHECK_LIMIT_CORES_ method ...")

## When set to true-ish value, should return 2
Sys.setenv(`_R_CHECK_LIMIT_CORES_` = "TRUE")
ncores <- availableCores(methods = "_R_CHECK_LIMIT_CORES_")
print(ncores)
stopifnot(ncores == 2L)

## When set to "warn", should also return 2
Sys.setenv(`_R_CHECK_LIMIT_CORES_` = "warn")
ncores <- availableCores(methods = "_R_CHECK_LIMIT_CORES_")
print(ncores)
stopifnot(ncores == 2L)

## When set to "false", should return NA
Sys.setenv(`_R_CHECK_LIMIT_CORES_` = "false")
ncores <- availableCores(methods = "_R_CHECK_LIMIT_CORES_", na.rm = FALSE)
print(ncores)
stopifnot(is.na(ncores))

## Cleanup
Sys.unsetenv("_R_CHECK_LIMIT_CORES_")

message("*** _R_CHECK_LIMIT_CORES_ method ... done")


message("*** nproc method ...")

## Check if nproc is available
has_nproc <- nzchar(Sys.which("nproc"))
message(sprintf("  - nproc available: %s", has_nproc))

if (has_nproc) {
  ## Reset getNproc cache
  env <- environment(parallelly:::getNproc)
  env$res <- NULL

  ## Test nproc method
  ncores <- availableCores(methods = "nproc")
  print(ncores)
  stopifnot(length(ncores) == 1L, is.integer(ncores), ncores >= 1L)

  ## Test OMP variable handling
  message("  - Testing OMP variable handling")

  ## Reset cache
  env$res <- NULL

  ## Set OMP variables that could influence nproc
  old_omp_threads <- Sys.getenv("OMP_NUM_THREADS", unset = NA)
  old_omp_limit <- Sys.getenv("OMP_THREAD_LIMIT", unset = NA)

  Sys.setenv(OMP_NUM_THREADS = "2", OMP_THREAD_LIMIT = "4")

  ## getNproc should ignore these when querying
  env$res <- NULL
  n <- parallelly:::getNproc()
  message(sprintf("  - getNproc() with OMP vars set: %s",
                  if (is.na(n)) "NA" else as.character(n)))

  ## Verify OMP variables are restored after call
  stopifnot(Sys.getenv("OMP_NUM_THREADS") == "2")
  stopifnot(Sys.getenv("OMP_THREAD_LIMIT") == "4")

  ## Restore original OMP values
  if (is.na(old_omp_threads)) {
    Sys.unsetenv("OMP_NUM_THREADS")
  } else {
    Sys.setenv(OMP_NUM_THREADS = old_omp_threads)
  }
  if (is.na(old_omp_limit)) {
    Sys.unsetenv("OMP_THREAD_LIMIT")
  } else {
    Sys.setenv(OMP_THREAD_LIMIT = old_omp_limit)
  }

  ## Reset cache for other tests
  env$res <- NULL
}

message("*** nproc method ... done")


message("*** /proc/self/status method ...")

## Test /proc/self/status method on Linux
if (file.exists("/proc/self/status")) {
  ncores <- availableCores(methods = "/proc/self/status")
  print(ncores)
  stopifnot(length(ncores) == 1L, is.integer(ncores))
  if (!is.na(ncores)) {
    stopifnot(ncores >= 1L)
  }
}

## 'Cpus_allowed_list' may list CPUs that are not online, e.g. '0-63'
## on a machine with 48 CPUs. Only CPUs that are online should count
getProcSelfStatusCpuSet <- parallelly:::getProcSelfStatusCpuSet
status <- tempfile()
online <- tempfile()
writeLines(c("Name:\tR", "Cpus_allowed:\tffffffff,ffffffff", "Cpus_allowed_list:\t0-63"), con = status)
writeLines("0-47", con = online)
cpus <- getProcSelfStatusCpuSet(status = status, online = online)
print(cpus)
stopifnot(identical(cpus, 0:47))

## A job's CPU set is not affected
writeLines(c("Name:\tR", "Cpus_allowed_list:\t25,45,77,97"), con = status)
writeLines("0-103", con = online)
cpus <- getProcSelfStatusCpuSet(status = status, online = online)
print(cpus)
stopifnot(identical(cpus, c(25L, 45L, 77L, 97L)))

## Online CPUs may be non-contiguous
writeLines(c("Name:\tR", "Cpus_allowed_list:\t0-7"), con = status)
writeLines("0-1,4-5", con = online)
cpus <- getProcSelfStatusCpuSet(status = status, online = online)
print(cpus)
stopifnot(identical(cpus, c(0L, 1L, 4L, 5L)))

## Without information on online CPUs, all allowed CPUs are returned
cpus <- getProcSelfStatusCpuSet(status = status, online = tempfile())
print(cpus)
stopifnot(identical(cpus, 0:7))

## No 'Cpus_allowed_list' gives an empty set
writeLines("Name:\tR", con = status)
cpus <- getProcSelfStatusCpuSet(status = status, online = online)
stopifnot(identical(cpus, integer(0L)))
file.remove(c(status, online))

message("*** /proc/self/status method ... done")


message("*** fraction parameter ...")

## fraction = 1 should be the same as default
n0 <- availableCores()
n <- availableCores(fraction = 1.0)
stopifnot(identical(n, n0))

## fraction = 0.5 on system cores (which we know)
n_sys <- availableCores(methods = "system")
n <- availableCores(methods = "system", fraction = 0.5)
stopifnot(length(n) == 1, is.integer(n), n >= 1L)
stopifnot(n == max(1L, as.integer(floor(0.5 * n_sys))))

## fraction = 0.7 with omit = 1
n <- availableCores(methods = "system", fraction = 0.7, omit = 1)
stopifnot(length(n) == 1, is.integer(n), n >= 1L)
expected <- max(1L, as.integer(floor(0.7 * n_sys)) - 1L)
stopifnot(n == expected)

## fraction should preserve names
n <- availableCores(methods = "system", fraction = 0.5)
stopifnot(identical(names(n), "system"))
n_all <- availableCores(which = "all")
n <- availableCores(which = "all", fraction = 0.5)
stopifnot(identical(names(n), names(n_all)))

## fraction should always return at least 1
n <- availableCores(methods = "system", fraction = 0.01)
stopifnot(n >= 1L)

## fraction combined with omit should always return at least 1
n <- availableCores(methods = "system", fraction = 0.01, omit = 100)
stopifnot(n >= 1L)

## Input validation
res <- tryCatch(availableCores(fraction = 0), error = identity)
stopifnot(inherits(res, "error"))

res <- tryCatch(availableCores(fraction = -0.5), error = identity)
stopifnot(inherits(res, "error"))

res <- tryCatch(availableCores(fraction = 1.5), error = identity)
stopifnot(inherits(res, "error"))

res <- tryCatch(availableCores(fraction = NA), error = identity)
stopifnot(inherits(res, "error"))

res <- tryCatch(availableCores(fraction = "half"), error = identity)
stopifnot(inherits(res, "error"))

message("*** fraction parameter ... done")


message("*** availableCores(methods.excludes) ...")
# Save original option
oopts <- options(parallelly.availableCores.methods.excludes = NULL)

methods0 <- names(availableCores(na.rm = FALSE, which = "all"))

# Exclude one method via option
options(parallelly.availableCores.methods.excludes = "system")
methods1 <- names(availableCores(na.rm = FALSE, which = "all"))
stopifnot(
  !"system" %in% methods1,
  all(setdiff(methods0, "system") %in% methods1)
)

# Exclude multiple methods via option (vector)
options(parallelly.availableCores.methods.excludes = c("system", "nproc"))
methods2 <- names(availableCores(na.rm = FALSE, which = "all"))
stopifnot(
  !any(c("system", "nproc") %in% methods2),
  all(setdiff(methods0, c("system", "nproc")) %in% methods2)
)

# Exclude multiple methods via option (comma-separated string)
options(parallelly.availableCores.methods.excludes = "system, nproc")
methods2b <- names(availableCores(na.rm = FALSE, which = "all"))
stopifnot(
  !any(c("system", "nproc") %in% methods2b),
  all(setdiff(methods0, c("system", "nproc")) %in% methods2b)
)

# Exclude via environment variable
options(parallelly.availableCores.methods.excludes = NULL)
Sys.setenv(R_PARALLELLY_AVAILABLECORES_METHODS_EXCLUDES = "system,nproc")
parallelly:::update_package_options()
methods3 <- names(availableCores(na.rm = FALSE, which = "all"))
stopifnot(
  !any(c("system", "nproc") %in% methods3),
  all(setdiff(methods0, c("system", "nproc")) %in% methods3)
)
Sys.unsetenv("R_PARALLELLY_AVAILABLECORES_METHODS_EXCLUDES")
parallelly:::update_package_options()

# Restore options
options(oopts)
message("*** availableCores(methods.excludes) ... done")


message("*** availableCores(max, which = 'all') ...")

## When 'which = "all"' and methods disagree, 'max' should clamp each
## method's value independently, preserving names and length [#XXX]
Sys.setenv(NSLOTS = "3")
ns0 <- availableCores(methods = c("system", "NSLOTS"), which = "all")
stopifnot(length(ns0) == 2, identical(names(ns0), c("system", "NSLOTS")))

ns <- availableCores(methods = c("system", "NSLOTS"), which = "all", max = 6L)
print(ns)
stopifnot(
  length(ns) == length(ns0),
  identical(names(ns), names(ns0)),
  all(ns <= 6L),
  ns[["NSLOTS"]] == 3L  ## unaffected, since already <= max
)
Sys.unsetenv("NSLOTS")

## Missing values should remain missing values when 'na.rm = FALSE'
Sys.unsetenv("NSLOTS")
ns <- availableCores(methods = c("system", "NSLOTS"), which = "all", na.rm = FALSE, max = 6L)
print(ns)
stopifnot(
  length(ns) == 2L,
  identical(names(ns), c("system", "NSLOTS")),
  is.integer(ns),
  ns[["system"]] <= 6L,
  is.na(ns[["NSLOTS"]])
)

message("*** availableCores(max, which = 'all') ... DONE")


message("*** availableCores(threadsPerWorker) ...")

options(parallelly.availableCores.system = 12L)
options(parallelly.availableCores.methods = "system")

env <- environment(parallelly:::detectCores)
env$cache <- list(NULL, NULL)

stopifnot(identical(availableCores(), c(system = 12L)))
stopifnot(identical(availableCores(threadsPerWorker = 1L), c(system = 12L)))
stopifnot(identical(availableCores(threadsPerWorker = 2L), c(system = 6L)))
stopifnot(identical(availableCores(threadsPerWorker = 3L), c(system = 4L)))


## At least one worker
stopifnot(identical(availableCores(threadsPerWorker = 100L), c(system = 1L)))

## Applied before 'omit' and 'fraction'
stopifnot(identical(availableCores(threadsPerWorker = 2L, omit = 1L), c(system = 5L)))
stopifnot(identical(availableCores(threadsPerWorker = 2L, fraction = 0.5), c(system = 3L)))

## Via option
options(parallelly.availableCores.threadsPerWorker = 4L)
stopifnot(identical(availableCores(), c(system = 3L)))
options(parallelly.availableCores.threadsPerWorker = NULL)

## Invalid values
for (value in list(0L, -1L, NA_integer_, Inf, 1:2, "2")) {
  res <- tryCatch(availableCores(threadsPerWorker = value), error = identity)
  stopifnot(inherits(res, "error"))
}

options(parallelly.availableCores.system = NULL)
options(parallelly.availableCores.methods = NULL)

message("*** availableCores(threadsPerWorker) ... DONE")


message("*** availableCores() ... DONE")
